#!/usr/bin/env bash
set -euo pipefail

ABI="arm64-v8a"
BUILD_ID="62126j12"
NDK_VERSION="27.2.12479018"
BUNDLE_ROOT="$(cd "$(dirname "$0")/.." && pwd -P)"
SDK_ROOT="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"

if [[ -z "$SDK_ROOT" ]]; then
  echo "Set ANDROID_SDK_ROOT to an Android SDK containing NDK $NDK_VERSION." >&2
  exit 2
fi
NDK="$SDK_ROOT/ndk/$NDK_VERSION"
if [[ ! -d "$NDK" ]]; then
  echo "Android NDK $NDK_VERSION is missing at $NDK" >&2
  exit 2
fi

HOST_TAG="darwin-arm64"
[[ -d "$NDK/toolchains/llvm/prebuilt/$HOST_TAG" ]] || HOST_TAG="darwin-x86_64"
if [[ ! -x "$NDK/toolchains/llvm/prebuilt/$HOST_TAG/bin/clang++" ]]; then
  echo "No supported macOS NDK toolchain found in $NDK/toolchains/llvm/prebuilt" >&2
  exit 2
fi

# The captured CMake command refers to these application-relative paths. Create
# them in the extracted bundle and copy only the supplied LGPL materials.
APP="$BUNDLE_ROOT/src-capacitor/android/app"
PREBUILT="$APP/src/main/cpp/prebuilt/$ABI"
BUILD="$APP/.cxx/RelWithDebInfo/$BUILD_ID/$ABI"
OUTPUT="$APP/build/intermediates/cxx/RelWithDebInfo/$BUILD_ID/obj/$ABI"
mkdir -p "$BUNDLE_ROOT/native-engine/jni" "$PREBUILT" \
  "$BUILD/CMakeFiles/audioengine.dir" "$OUTPUT"
cp -R "$BUNDLE_ROOT/native-engine/prebuilt/$ABI/." "$PREBUILT/"
cp "$BUNDLE_ROOT/relink/android-object/$ABI/AudioEngine.cpp.o" \
  "$BUILD/CMakeFiles/audioengine.dir/AudioEngine.cpp.o"

export BUNDLE_ROOT SDK_ROOT HOST_TAG
COMMAND="$(python3 - "$BUNDLE_ROOT/relink/LINK_COMMAND.txt" <<'PY'
from pathlib import Path
import os
import shlex
import sys

command = Path(sys.argv[1]).read_text()
command = command.replace("<PACKAGE_ROOT>", shlex.quote(os.environ["BUNDLE_ROOT"]))
command = command.replace("<ANDROID_SDK_ROOT>", shlex.quote(os.environ["SDK_ROOT"]))
command = command.replace("prebuilt/darwin-x86_64/", f"prebuilt/{os.environ['HOST_TAG']}/")
print(command)
PY
)"

(
  cd "$BUILD"
  bash -euo pipefail -c "$COMMAND"
)
echo "Relinked library: $OUTPUT/libaudioengine.so"
