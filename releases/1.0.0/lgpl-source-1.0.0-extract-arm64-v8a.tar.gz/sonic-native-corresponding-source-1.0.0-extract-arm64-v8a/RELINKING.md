# Relinking instructions

This bundle corresponds to app version 1.0.0, Android variant extract,
ABI arm64-v8a. It contains the exact upstream source archives and checksums in
native-engine/NOTICE.md, the native build script and codec helper, generated
FFmpeg config (with machine-specific root paths tokenized), licence texts,
static libraries and headers for arm64-v8a, the
matching AudioEngine.cpp.o, and the exact generated link command. It excludes
the app's proprietary source. No signing key or credential is included.

## Rebuild the native libraries

Install Android SDK/NDK 27.2.12479018 and run
`ANDROID_SDK_ROOT=/absolute/path/to/android-sdk NATIVE_PREBUILT_DIR="$PWD/native-engine/prebuilt" bash native-engine/build-android.sh arm64-v8a`.
The script verifies each upstream archive SHA-256 before extraction. Its
configure flags are recorded in the script and generated config. GPL,
version 3, and nonfree FFmpeg components are disabled.

## Relink the native library

FFmpeg and the codec libraries are statically linked into libaudioengine.so.
The bundle includes the app's AudioEngine.cpp.o object, every linked static
archive, headers, and the generated link command. From a writable directory,
run `ANDROID_SDK_ROOT=/absolute/path/to/android-sdk bash relink/relink.sh`.
The helper copies the supplied materials into the paths expected by the
captured command, expands the workspace and SDK tokens, and invokes the NDK
linker. The resulting libaudioengine.so is written under
src-capacitor/android/app/build/intermediates/cxx/. The helper needs Android
NDK 27.2.12479018. The object contains the app's native implementation; source
for that object is not included.

This is the corresponding-source and relink package for this exact app
version, variant, and ABI. Do not substitute source archives or objects from
another release.
